package appiumtest;

import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Test1 {
	static AppiumDriver<MobileElement> driver;

//	public static void main(String[] args) {
//		
////		try {
////			openApp();
////			
////		} catch(Exception exp) {
////			System.out.println(exp.getCause());
////			System.out.println(exp.getMessage());
////			exp.printStackTrace();
////			
////		}
////	}
////	
////	public static void openApp() throws Exception {
////		
////		
////		
////		
////		
////		
////		
//	}
	
	@Given("User on home page")
	public void user_on_home_page() throws Exception {
		DesiredCapabilities cap = new DesiredCapabilities();

		cap.setCapability("automationName ", "uiautomator2");
		cap.setCapability("deviceName", "Android SDK built for x86");
		cap.setCapability("udid", "emulator-5554");
		cap.setCapability("platformName", "Android");
		cap.setCapability("platformVersion", "11");
		cap.setCapability("appPackage", "com.saucelabs.mydemoapp.android");
		cap.setCapability("appActivity", "com.saucelabs.mydemoapp.android.view.activities.MainActivity");
		cap.setCapability("app", "C:\\Users\\User\\Desktop\\Bibit\\mda-1.0.13-15.apk");
		cap.setCapability("noReset ", "true");
	
		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		
		driver = new AppiumDriver<MobileElement>(url, cap);
	}
	
	@When("User kilk product")
	public void user_kilk_product() throws Exception {
		System.out.println("Start");
		Thread.sleep(5000);
		MobileElement el1 = (MobileElement) driver.findElementByXPath("");//produk 1
		el1.click();
		Thread.sleep(5000);
	}

	@Then("User press button biru dan button plus")
	public void user_press_button_biru_dan_button_plus() throws Exception {
		MobileElement el2 = (MobileElement) driver.findElementByXPath("");//klik warna biru
		el2.click();
		Thread.sleep(5000);
		MobileElement el3 = (MobileElement) driver.findElementByXPath("");//klik button plus
		el3.click();
		Thread.sleep(5000);
	}

	@And("User klik button Add to cart")
	public void user_klik_button_add_to_cart() throws Exception {
		MobileElement el4 = (MobileElement) driver.findElementByXPath("");//klik button add to cart
		el4.click();
		Thread.sleep(5000);
		System.out.println("Done");
	}
	//Sementara saya kosongkan elementnya dikarenakan aplikasi tidak dapat di run di emulator android mungkin penyebab karena aplikasi dari Saucelab dan saya juga belum sempat untuk mempelajarinya
}



